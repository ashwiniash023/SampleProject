import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.Arrays;

public class TestRunner {

    public static By logInButton = By.xpath("//header[@data-testid='bignav']//a[contains(text(),'Log in')]");
    public static By userNameTextbox = By.xpath("//input[@id='username']");
    public static By passwordTextbox = By.xpath("//input[@id='password']");
    public static By continueButton = By.xpath("//button[contains(@id,'login-submit')]//span[contains(text(),'Continue')]");
    public static By logInSubmitButton = By.xpath("//button[contains(@id,'login-submit')]//span[contains(text(),'Log in')]");
    public static By logInUserProfile = By.xpath("//div[@role='presentation']//button[contains(@data-testid,'member-menu')]//span");
    public static By logOutButton = By.xpath("//span[contains(text(),'Log out')]");
    public static By createWorkSpace = By.xpath("//button[contains(@aria-label,'Workspace')]//span[contains(@class,'icon-add')]");
    public static By workSpaceNameInput = By.xpath("//input[contains(@id,'create-team')]");

    public static By workSpaceTypeButton = By.xpath("//div[contains(text(),'Choose')]");

    public static By workSpaceContinueButton = By.xpath("//button[contains(text(),'Continue')]");

    public static By selectWorkSpace = By.xpath("//span[contains(text(),'TestWorkspaceInput')]");

    public static By boards = By.xpath("//span[contains(text(),'TestWorkspaceInput')]//parent::a//following-sibling::ul//span[contains(text(),'Boards')]");

    public static By createButton = By.xpath("//p[contains(text(),'Create')]");

    public static By createBoardButton = By.xpath("//span[contains(text(),'Create board')]");

    public static By createBoardTitle = By.xpath("//input[contains(@data-testid,'create-board-title-input')]");
    public static By createBoardTemplateButton = By.xpath("//button[contains(text(),'Start with a template')]");
    public static By createBoardModalButton = By.xpath("//h2[contains(text(),'Kanban Template')]//ancestor::section//button[contains(text(),'Create')]");
    public static By addACardButton1 = By.xpath("//h2[contains(text(),'To Do')]//ancestor::li//button[contains(text(),'Add a card')]//span");
    public static By addBoardConfirmButton1 = By.xpath("//h2[contains(text(),'To Do')]//ancestor::li//button[contains(text(),'Add card')]");
    //h2[contains(text(),'Doing')]//ancestor::div[contains(@class,'list js-list-content')]//span[contains(text(),'Add a card')]
    public static String [] addACardButton = {"//h2[contains(text(),'","')]//ancestor::div[contains(@class,'list js-list-content')]//span[contains(text(),'Add a card')]"};
    public static String [] addCardConfirmButton = {"//h2[contains(text(),'","')]//ancestor::div[contains(@class,'list js-list-content')]//input[contains(@value,'Add card')]"};
    public static String [] addCardTitleButton = {"//h2[contains(text(),'","')]//ancestor::div[contains(@class,'list js-list-content')]//textarea[contains(@placeholder,'Enter a title for this card')]"};
    public static String [] validateCardCreated = {"//h2[contains(text(),'","')]//ancestor::div[contains(@class,'list js-list-content')]//span[text()='","']"};

    public static By addCardTitleButton1 = By.xpath("//h2[contains(text(),'To Do')]//ancestor::li//textarea[contains(@placeholder,'Enter a title for this card')]");
    public static By validateCardCreated1 = By.xpath("//h2[contains(text(),'To Do')]//ancestor::li//a[text()='Create Test Case']");
    public static By moveButton = By.xpath("//span[contains(text(),'Move')]");
    public static By moveToListButton = By.xpath("//select[contains(@data-testid,'move-card-popover-select-list-destination')]");
    public static By moveConfirmButton = By.xpath("//input[contains(@value,'Move')]");
    public static By positionConfirmButton = By.xpath("//select[contains(@data-testid,'move-card-popover-select-position')]");

    public static By closeDialogButton = By.xpath("//a[contains(@aria-label,'Close dialog')]");

    public static By keepCards = By.xpath("//span[contains(@class,'VhaiZhQslxcjfC')]");

    public static By kanbanTemplate = By.xpath("//div[contains(@data-testid,'template-picker-container')]//div[contains(text(),'Kanban Template')]");

    public static By collapseButton= By.xpath("//img[@alt='Workspace navigation collapse icon']");

    public static By logoutValidation = By.xpath("(//input[contains(@name,'email')])[1]");

    public static By overflowMenu = By.xpath("//div[contains(@class,'RPO6eTW4FLJhI0')]//span[contains(@data-testid,'OverflowMenuHorizontalIcon')]");

    public static By closeBoardButton = By.xpath("//a[contains(text(),'Close board')]");

    public static By closeButton = By.xpath("//input[contains(@value,'Close')]");

    public static By permanentlyDeleteButton = By.xpath("//button[contains(text(),'Permanently delete board')]");

    public static By deleteButton = By.xpath("//button[contains(text(),'Delete')]");

    public static By workspaceName = By.xpath("//h2[contains(text(),'TestWorkspaceInput')]");


    public static WebDriverWait wait;

    public static String endPointURL = "https://trello.com";
    public static WebDriver driver;

    //ExtentSparkReporter spark = new ExtentSparkReporter("Spark.html");

//    {
//        ExtentReports extent = new ExtentReports();
//        ExtentSparkReporter spark = new ExtentSparkReporter("target/Spark.html");
//        spark.config().setTheme(Theme.DARK);
//        spark.config().setDocumentTitle("MyReport");
//        extent.attachReporter(spark);
//
//
//    }
    public static void main(String [] args)
    {

    }

    public static void clickElement(By element)
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(element));
        driver.findElement(element).click();
    }

    @Test(priority = 1)
    public static void loginToApplication()
    {
        System.out.println(System.getProperty("user.dir"));
        System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/resources/chromedriver");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("start-maximized");
        options.setExperimentalOption("excludeSwitches", Arrays.asList("disable-popup-blocking"));
        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver,240);

        //Launch the application
        driver.get(endPointURL);
        Reporter.log("Launched the application successfully");

        //Login to application
        clickElement(logInButton);
        sendKeysToElement(userNameTextbox,"durgapramodh10dj95@gmail.com");
        clickElement(continueButton);
        sendKeysToElement(passwordTextbox,"10TRELLO@95");
        clickElement(logInSubmitButton);
        Reporter.log("/n");
        Reporter.log("User is logged in successfully");

        Assert.assertTrue(validatePresenceOfElement(selectWorkSpace),"User is logged in successfully");
    }

    @Test(priority = 2)
    public static void navigateToWorkSpaceAndSelectBoards()
    {
        clickElement(selectWorkSpace);
        Assert.assertTrue(validatePresenceOfElement(boards),"User failed to navigate to workspace");
        Reporter.log("User is navigated to workspace successfully");
        clickElement(boards);
    }

 @Test(priority = 3)
    public static void createBoardUsingTemplate()
    {
        clickElement(createButton);
        clickElement(createBoardButton);


        clickElement(createBoardTemplateButton);
        Assert.assertTrue(validatePresenceOfElement(kanbanTemplate),"Templates are not displayed");
        Reporter.log("User is able to select the pre defined template");
        clickElement(kanbanTemplate);
        Assert.assertTrue(validatePresenceOfElement(keepCards),"User selected the predefined template successfully");
        Reporter.log("User is able to create template without predefined cards");

        clickElement(keepCards);

        wait.until(ExpectedConditions.visibilityOfElementLocated(createBoardTitle));
        driver.findElement(createBoardTitle).clear();
        sendKeysToElement(createBoardTitle,"Test Board Kanban");



        clickElement(createBoardModalButton);
        Reporter.log("User is able to create Kanban board successfully");
    }

    @Test(priority = 4)
    public static void collapseSideView()
    {
        clickElement(collapseButton);
        Reporter.log("User is able to collapse side view successfully");
    }

    @Test(priority = 5)
    public static void createCard()
    {
        createCard("Doing","Gather Requirements");
        createCard("Code Review","Start development");
//        createCard("Doing","Setup Infrastructure");
//        createCard("Doing","Working on POC");
    }

    @Test(priority = 6)
    public static void moveCard()
    {
        moveCard("Gather Requirements","Testing");
//        moveCard("Setup Infrastructure","Testing");
//        moveCard("Working on POC","Testing");
    }

    @Test(priority = 7)
    public static void deleteBoard()
    {

        clickElement(overflowMenu);
        clickElement(closeBoardButton);
        clickElement(closeButton);
        clickElement(permanentlyDeleteButton);
        clickElement(deleteButton);
        Assert.assertTrue(validatePresenceOfElement(workspaceName),"Board is not deleted successfully");
        Reporter.log("Board is deleted successfully");
    }

    @Test(priority = 8)
    public static void logOut()
    {

        clickElement(logInUserProfile);
        clickElement(logOutButton);
        clickElement(logOutButton);
        wait.until(ExpectedConditions.presenceOfElementLocated(logoutValidation));
        Assert.assertTrue(driver.findElement(logoutValidation).isDisplayed(),"Log out is successfull");
        Reporter.log("User is able to logout successfully");
    }

   // @Test
    public static void clickElementabc()
    {
        /*System.out.println(System.getProperty("user.dir"));
        System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/src/resources/chromedriver");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("start-maximized");
        options.setExperimentalOption("excludeSwitches", Arrays.asList("disable-popup-blocking"));
        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver,240);

        //Launch the application
        driver.get(endPointURL);

        //Login to application
        clickElement(logInButton);
        sendKeysToElement(userNameTextbox,"durgapramodh10dj95@gmail.com");
        clickElement(continueButton);
        sendKeysToElement(passwordTextbox,"10TRELLO@95");
        clickElement(logInSubmitButton);*/

        /*clickElement(selectWorkSpace);
        clickElement(boards);*/



        /*clickElement(createButton);
        clickElement(createBoardButton);

        clickElement(createBoardTemplateButton);

        clickElement(kanbanTemplate);

        clickElement(keepCards);

        wait.until(ExpectedConditions.visibilityOfElementLocated(createBoardTitle));
        driver.findElement(createBoardTitle).clear();
        sendKeysToElement(createBoardTitle,"Test Board Kanban");

        clickElement(createBoardModalButton);*/

        /*clickElement(collapseButton);*/

        /*createCard("Doing","Gather Requirements");
        createCard("Code Review","Start development");
        createCard("Doing","Setup Infrastructure");
        createCard("Doing","Working on POC");*/


       /* moveCard("Gather Requirements","Testing");
        moveCard("Setup Infrastructure","Testing");
        moveCard("Working on POC","Testing");*/



//
//        //create the workspace
//        clickElement(createWorkSpace);
//        sendKeysToElement(workSpaceNameInput,"TestWorkspaceInput");
//        clickElement(workSpaceTypeButton);
//        try {
//            sendKeyBoardKeys(workSpaceTypeButton,"TAB");
//        } catch (InterruptedException e) {
//            throw new RuntimeException(e);
//        }
//        clickElement(workSpaceContinueButton);

//        wait.until(ExpectedConditions.visibilityOfElementLocated(element));
//        driver.findElement(element).click();
    }

    public static void sendKeysToElement(By element,String value)
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(element));
        driver.findElement(element).sendKeys(value);
    }

    public static boolean validatePresenceOfElement(By element)
    {
        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(element));
            return driver.findElement(element).isDisplayed();
        }
        catch(Exception e)
        {
            return false;
        }
    }

    public static void selectByOption(By element,String value)
    {
        wait.until(ExpectedConditions.presenceOfElementLocated(element));
        clickElement(element);
        Select selectMenu = new Select(driver.findElement(element));
        selectMenu.selectByVisibleText(value);

    }
    public static void createCard(String listName, String cardName)
    {

        JavascriptExecutor js = (JavascriptExecutor) driver;

        js.executeScript("arguments[0].scrollIntoView();", driver.findElement(getElement(addACardButton,listName)));
        clickElement(getElement(addACardButton,listName));
        sendKeysToElement(getElement(addCardTitleButton,listName),cardName);
        clickElement(getElement(addCardConfirmButton,listName));
        Assert.assertTrue(driver.findElement(By.xpath(validateCardCreated[0]+listName+validateCardCreated[1]+cardName+validateCardCreated[2])).getText().equals(cardName));
        Reporter.log("User is able to create card "+cardName+" in list "+listName+" successfully");
    }

    public static void moveCard(String cardName,String destinationList)
    {
        clickElement(By.xpath(validateCardCreated[0]+""+validateCardCreated[1]+cardName+validateCardCreated[2]));
        clickElement(moveButton);
        selectByOption(moveToListButton,destinationList);
        clickElement(moveConfirmButton);
        clickElement(closeDialogButton);
        Reporter.log("User is able to move card "+cardName+" to list "+destinationList+" successfully");
    }

    public static By getElement(String [] dynamicXpath, String dynamicValue)
    {
        return By.xpath(dynamicXpath[0]+dynamicValue+dynamicXpath[1]);
    }
}
